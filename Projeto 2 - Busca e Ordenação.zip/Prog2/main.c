#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


struct funcionario
{
    int id;
    char nome[100];
    float salario;
};

struct funcionario_ordem
{
    char nomeo[100];
    float salarioo;
};

struct funcionario_novo
{
    int idn;
    char nomen[100];
    float salarion;
};

struct projeto
{
    char nome_projeto[100];
    char data_inicio[50];
    char data_termino[50];
    int tempo_estimado;
    float valor_estimado;
    int id_func;
    int situacao;
};

struct projeto_novo
{
    char nome_projeton[100];
    char data_inicion[50];
    char data_terminon[50];
    int tempo_estimadon;
    float valor_estimadon;
    int id_funcn;
    int situacaon;

};

struct funcionario lista_funcionarios[50];
struct projeto lista_projetos[50];
struct projeto_novo lista_projetos_novo[50];
struct funcionario_novo lista_funcionarios_novo[50];
struct funcionario_ordem lista_funcionarios_ordem[50];

void cadastra_projeto (int* tamanho_lista_p)
{

    printf("\nInforme o nome do projeto: ");
    scanf(" %100[^\n]s",lista_projetos[*tamanho_lista_p].nome_projeto);
    printf("\nData de inicio (DD-MM-AAAA): ");
    scanf(" %s",lista_projetos[*tamanho_lista_p].data_inicio);
    printf("\nData de termino (DD-MM-AAAA): ");
    scanf(" %s", lista_projetos[*tamanho_lista_p].data_termino);
    printf("\nTempo estimado do projeto (meses): ");
    scanf("%d",&lista_projetos[*tamanho_lista_p].tempo_estimado);
    printf("\nValor estimado do projeto: ");
    scanf("%f",&lista_projetos[*tamanho_lista_p].valor_estimado);
    printf("\nID do funcionario responsavel pelo projeto: ");
    scanf("%d",&lista_projetos[*tamanho_lista_p].id_func);
    printf("Situacao do projeto (1- Em andamento 2- Atrasado 3- Concluido): ");
    scanf("%d",&lista_projetos[*tamanho_lista_p].situacao) ;

    (*tamanho_lista_p)++;

}

void mostrarVet(struct funcionario_ordem *lista_funcionario_ordem, int *N)
{

    int i;

    for (i=0; i < *N; i++)
    {
        printf("Nome: %s\n",lista_funcionario_ordem[i].nomeo);
        printf("Salario: %.2f\n\n",lista_funcionario_ordem[i].salarioo);

    }

}




void salario_desc( struct funcionario *lista_funcionario, int *N, struct funcionario_ordem  *lista_funcionario_ordem)
{

    int j;
    int aux,a,contador;


    for (j=0; j < *N; j++ )
    {
        strcpy(lista_funcionario_ordem[j].nomeo,lista_funcionario[j].nome);
        lista_funcionario_ordem[j].salarioo = lista_funcionario[j].salario;

    }

    for (contador = 0; contador < *N; contador++)
    {

        for (a = 0; a < *N-1; a++)
        {
            if (lista_funcionario_ordem[a].salarioo < lista_funcionario_ordem[a+1].salarioo )
            {

                struct funcionario_ordem aux = lista_funcionario_ordem[a];
                lista_funcionario_ordem[a] = lista_funcionario_ordem[a + 1];
                lista_funcionario_ordem[a + 1] = aux;
            }
        }
    }


}



void trocarNovo (struct projeto_novo *lista_projeto_novo, int x, int y)
{

    struct projeto_novo aux = lista_projeto_novo[x];
    lista_projeto_novo[x] = lista_projeto_novo[y];
    lista_projeto_novo[y] = aux;

}

void mostrarnovo(struct projeto_novo *lista_projeto_novo, int *N)
{
    system("cls");
    int i;

    for (i=0; i < *N; i++)
    {
        printf("\nNome do projeto: %s\n",lista_projeto_novo[i].nome_projeton);
        printf("\nData de inicio (DD-MM-AAAA): %s\n",lista_projeto_novo[i].data_inicion);
        printf("\nData de termino (DD-MM-AAAA): %s\n", lista_projeto_novo[i].data_terminon);
        printf("\nTempo estimado do projeto (meses): %d\n",lista_projeto_novo[i].tempo_estimadon);
        printf("\nValor estimado do projeto: %.2f\n",lista_projeto_novo[i].valor_estimadon);
        printf("\nID do funcionario responsavel pelo projeto: %d\n",lista_projeto_novo[i].id_funcn);
        printf("Situacao do projeto (1- Em andamento 2- Atrasado 3- Concluido): %d\n",  lista_projeto_novo[i].situacaon);

    }
}

void mostrarfuncionario(struct funcionario_novo *lista_funcionario_novo, int *N)
{
    system("cls");
    int i;

    for (i=0; i < *N; i++)
    {
        printf("ID: %d\n",lista_funcionario_novo[i].idn);
        printf("Nome funcionario: %s\n", lista_funcionario_novo[i].nomen);
        printf("Salario do funcionario: %2.f\n\n",lista_funcionario_novo[i].salarion);
    }

}

void projeto_nterminado( struct projeto *lista_projeto, int *N, struct projeto_novo  *lista_projeto_novo, int *tamanho_lista_pn)
{

    int j,h,aux,a,contador;
    h=0;

    for ( j=0; j < *N; j++ )
    {


        if (lista_projeto[j].valor_estimado > 500000 && (lista_projeto[j].situacao == 1 || lista_projeto[j].situacao == 2))
        {

            (*tamanho_lista_pn)++;
            strcpy(lista_projeto_novo[h].nome_projeton,lista_projeto[j].nome_projeto);
            strcpy(lista_projeto_novo[h].data_inicion,lista_projeto[j].data_termino);
            strcpy(lista_projeto_novo[h].data_terminon,lista_projeto[j].data_termino);
            lista_projeto_novo[h].tempo_estimadon = lista_projeto[j].tempo_estimado;
            lista_projeto_novo[h].valor_estimadon = lista_projeto[j].valor_estimado;
            lista_projeto_novo[h].id_funcn = lista_projeto[j].id_func;
            lista_projeto_novo[h].situacaon = lista_projeto[j].situacao;


        }
        else continue;

        h++;
    }

    for (contador = 0; contador < h; contador++)
    {

        for (a = 0; a < h-1; a++)
        {
            if (lista_projeto_novo[a].valor_estimadon > lista_projeto_novo[a + 1].valor_estimadon)
            {

                struct projeto_novo aux = lista_projeto_novo[a];
                lista_projeto_novo[a] = lista_projeto_novo[a + 1];
                lista_projeto_novo[a + 1] = aux;
            }
        }
    }
}



void ordemalfa(struct funcionario *lista_funcionario, int *N, struct projeto *lista_projeto, int *M, struct funcionario_novo *lista_funcionario_novo, int* tamanho_lista_fn)
{

    int i,j,h,aux,a,contador;
    h=-1;

    for ( j=0; j < *N; j++ )
    {
        h++;

        for(i=0; i<*M; i++)
        {

            if (lista_funcionario[j].id == lista_projeto[i].id_func && lista_projeto[i].situacao == 1)
            {

                (*tamanho_lista_fn)++;

                lista_funcionario_novo[h].idn = lista_funcionario[i].id;
                strcpy(lista_funcionario_novo[h].nomen, lista_funcionario[i].nome);
                lista_funcionario_novo[h].salarion = lista_funcionario[i].salario;
                break;
            }
        }
    }

    for (contador = 1; contador < h; contador++)
    {

        for (a = 0; a < h-1; a++)
        {
            if (strcmp(lista_funcionario_novo[a].nomen,lista_funcionario_novo[a+1].nomen) > 0)
            {

                struct funcionario_novo aux = lista_funcionario_novo[a];
                lista_funcionario_novo[a] = lista_funcionario_novo[a + 1];
                lista_funcionario_novo[a + 1] = aux;
            }
        }
    }

}



void busca_funcionario(struct funcionario *lista_funcionario, int* N, int elem)
{
    int aux1,aux2,aux3,catarse,i,h;
    h=*N;
    i = elem - 1;
    catarse=1;
    aux1 =(h/2);
    aux2 = 1;
    aux3 = *N;

    if((elem > *N)||(elem<0))
    {
        printf("Nao existe funcionario\n");
    }
    else
    {
        while(catarse==1)
        {
            if(aux1==elem)
            {
                printf("Nome:  %s\n",lista_funcionarios[i].nome);
                printf("Salario: %.2f\n", lista_funcionario[i].salario);
                catarse=0;
            }
            else if(aux1<elem)
            {
                aux2=aux1;
                aux1=(aux3+aux2)/2;
                if((aux3+aux2)%2!= 0)
                {
                    aux1++;
                }
            }
            else if(aux1>elem)
            {
                aux3=aux1;
                aux1=(aux2+aux3)/2;
                if((aux2+aux3)%2 != 0)
                {
                    aux1--;
                }
            }
        }
    }
}


void atualizar(struct projeto *lista_projeto, int *N, char *nomep)
{
    int i,h,retorno;
    char str1[50],str2[50];


    for(i=0; i< *N; i++)
    {

        retorno = strcmp(nomep,lista_projeto[i].nome_projeto);

        if(retorno == 0)
        {
            printf("Qual a nova situacao do projeto?(1- Em andamento 2-  Atrasado 3- Concluido): \n");
            scanf("%d",&h);
            lista_projeto[i].situacao = h;
        }
        else
        {
            printf("Projeto nao existe!\n");
        }
    }


}
void Sobre(void)
{
    printf("\n\n\t\tAGENDA EM LINGUAGUEM C\n\n");
    printf("\tTrabalho para obten��o de nota Parcial\n\tNa Disciplina de Algoritmos e Estrutura de Dados\n");
    printf("\tIntegrantes da Equipe:\n\t\tDaniel Galdencio - PC3006115\n\t\tAntonio Jose Naranjo - PC3006042\n\t\tLucas Patricio - PC3010147\n\t\tLeticia Abelha - PC300662X\n\t\tRafael Foga�a - PC3005551");
    getch();
}


void cadastra_funcionario (int* tamanho_lista, int id)
{

    printf("ID: %d\n",id);
    lista_funcionarios[*tamanho_lista].id = id;

    printf("Informe o nome do funcionario \n");
    scanf(" %100[^\n]s]",lista_funcionarios[*tamanho_lista].nome);

    printf("Informe o salario do funcionario \n");
    scanf("%f%*c",
          &lista_funcionarios[*tamanho_lista].salario);
    (*tamanho_lista)++;

}



int main(void)
{

    int tamanho_lista = 0;
    int tamanho_lista_p = 0;
    int tamanho_lista_pn = 0;
    int tamanho_lista_fn = 0;
    int id=1;
    int meucu;
    int continuar = 0;
    int opcao;
    char voltar;
    char nomep[50];


    do
    {
menu:
        system("cls");
        printf("******MENU******\n\n");
        printf("1- Cadastrar Funcionario\n");
        printf("2- Cadastrar Projeto \n");
        printf("3- Buscar  funcionario\n");
        printf("4- Salario dos funcionarios em ordem decrescente\n");
        printf("5- Listar todos os projetos com valor acima de R$500.000,00 e que estejam em andamento e atrazo: (obs: ordem crescente) \n");
        printf("6- Listar em ordem alfabetica todos os funcionarios com  projetos em andamento \n");
        printf("8- Atualizar a situa��o de um projeto \n");
        printf("9- Sobre/Sair\n");
        scanf("%d", &opcao);

        switch (opcao)
        {

        case 1:
            system("cls");
            cadastra_funcionario( &tamanho_lista, id);
            id++;
            break;

        case 2:
case2:
            system("cls");
            cadastra_projeto( &tamanho_lista_p);
            printf("Deseja voltar ao menu ? (s/n)\n");
            scanf("%s",&voltar);
            if (voltar =='s')
            {
                goto menu;

            }
            else
            {
                goto case2;

            }
            break;

        case 3:
case3:
            system("cls");
            printf("Qual id voce quer buscar?\n");
            scanf("%d",&meucu);
            busca_funcionario(lista_funcionarios, &tamanho_lista, meucu);
            printf("Deseja voltar ao menu ? (s/n)\n");
            scanf("%s",&voltar);
            if (voltar =='s')
            {
                goto menu;

            }
            else
            {
                goto case3;

            }
            break;

        case 4:
case4:
            salario_desc(lista_funcionarios,&tamanho_lista, lista_funcionarios_ordem);
            mostrarVet(lista_funcionarios_ordem,&tamanho_lista);
            printf("Deseja voltar ao menu ? (s/n)\n");
            scanf("%s",&voltar);
            if (voltar =='s')
            {
                goto menu;

            }
            else
            {
                goto case4;

            }
            break;


        case 5:
case5:
            projeto_nterminado(lista_projetos,&tamanho_lista_p,lista_projetos_novo,&tamanho_lista_pn);
            mostrarnovo(lista_projetos_novo,&tamanho_lista_pn);
            printf("Deseja voltar ao menu ? (s/n)\n");
            scanf("%s",&voltar);
            if (voltar =='s')
            {
                goto menu;

            }
            else
            {
                goto case5;

            }
            break;

        case 6:
case6:
            ordemalfa(lista_funcionarios,&tamanho_lista, lista_projetos,&tamanho_lista_p,lista_funcionarios_novo,&tamanho_lista_fn);
            mostrarfuncionario(lista_funcionarios_novo,&tamanho_lista_fn);
            printf("Deseja voltar ao menu ? (s/n)\n");
            scanf("%s",&voltar);
            if (voltar =='s')
            {
                goto menu;

            }
            else
            {
                goto case6;

            }
            break;

        case 8:
case8:
            system("cls");
            printf("Qual o nome do projeto voce quer atualizar a situacao? \n");
            fflush(stdin);
            scanf(" %100[^\n]s", nomep);
            atualizar(lista_projetos,&tamanho_lista_p, nomep);
            printf("Deseja voltar ao menu ? (s/n)\n");
            scanf("%s",&voltar);
            if (voltar =='s')
            {
                goto menu;
            }
            else
            {
                goto case8;
            }
            break;
        case 9:
            system("cls");
            Sobre();
            continuar=1;
        }

    }
    while (continuar == 0);
    return 0;

}
